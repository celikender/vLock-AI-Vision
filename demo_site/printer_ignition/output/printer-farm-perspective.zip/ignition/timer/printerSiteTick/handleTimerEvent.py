def handleTimerEvent():
	printerSite.tick()
